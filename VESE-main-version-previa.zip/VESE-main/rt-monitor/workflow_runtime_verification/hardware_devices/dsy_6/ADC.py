import inspect
import numpy as np
from workflow_runtime_verification.hardware_devices.dsy_6 import ADCVisual
from workflow_runtime_verification.monitor import NoValue


class ADC:
    def __init__(self):
        AcumCalib = 0
        Calib = 0
        ContCalib = 0
        self._adc_read = NoValue()

        # statistics variables
        self.__total_values_read = 0
        self.__current_value = 0
        # create the visualization features associated
        self.__visualADC = ADCVisual.ADCVisual(parent=self, adc_comp=self)
        self.__visualADC.Show()

    def stop(self):
        self.__visualADC.close()

    def state(self):
        state = {"adc_read": [["uint16_t"], self._adc_read]}
        return state

    def ad_init(self):
        pass

    def lectura(self, channel: np.uint8, read: np.uint16):
        self._adc_read = read
        self.__total_values_read += 1
        self.__current_value = read

    def get_status(self):
        return [self.__total_values_read, self.__current_value]

    def Calibrar(self, Acum: np.int32, ord: np.int16, pend: np.int16):
        temp_pend = float(pend) / float(10000)
        temp_ord = float(ord & 0x7FFF) / float(1000)
        Acum = Acum >> 4
        if ord & 0x8000:
            Acum = int((Acum * temp_pend) - temp_ord + float(0.5))
        else:
            Acum = int((Acum * temp_pend) + temp_ord + float(0.5))
        return Acum

    def descarte(self, res: np.int16, cuentas_ant: np.int16, cont: np.char):
        UMBRAL = 5
        DESC = 5

        if res & 0x1000:
            res = res or 0xF000

        if (res < (cuentas_ant - UMBRAL)) and (cont > -DESC):
            res = cuentas_ant
            cont = cont - 1
            if cont > 0:
                cont = 0
            return

        if (res > (cuentas_ant + UMBRAL)) and (cont < DESC):
            res = cuentas_ant
            cont = cont + 1
            if cont < 0:
                cont = 0
            return

        cont = 0
        cuentas_ant = res

    # component exported methods
    exported_functions = {
        "ad_init": ad_init,
        "lectura": lectura,
        "Calibrar": Calibrar,
        "descarte": descarte,
    }

    def process_high_level_call(self, string_call):
        """
        this method receive as parameter an string_call containing a sequence of values, the first one is the
        class method name (e.g. lectura ), then a lists of parameters to its invocation.
        """
        # get information from string
        ls = string_call.split(",")
        function_name = ls[0]
        function = self.exported_functions[function_name]
        # get parameters
        args_str = ls[1:]
        # call the function
        self.run_with_args(function, args_str)
        return True

    def run_with_args(self, function, args):
        signature = inspect.signature(function)
        parameters = signature.parameters
        new_args = [self]
        for name, param in parameters.items():
            exp_type = param.annotation
            if exp_type is not inspect.Parameter.empty:
                try:
                    value = args[0]
                    args = args[1:]
                    value = exp_type(value)
                    new_args.append(value)
                except (TypeError, ValueError):
                    print(
                        f"Error: Can't convert the arg '{name}' al tipo {exp_type.__name__}"
                    )

        return function(*new_args)
